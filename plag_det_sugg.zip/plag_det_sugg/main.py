from flask import Flask, render_template, request
from document_similarity import get_document_similarity
from parrot import Parrot
import torch



app = Flask(__name__)

@app.route('/') 
def index(): 
    return render_template('home.html')

@app.route('/checker/', methods = ['POST'])
def checker():
    if request.method == 'POST':
        file1 = request.files['File1']
        h1 = file1.read().decode('utf-8').replace('\r', '').replace('\n', ' \\n')
        f2 = request.files['File2']
        h2 = f2.read().decode('utf-8').replace('\r', '').replace('\n', ' \\n')
        
        document_similarity = get_document_similarity (h1, h2)

        return render_template('compare.html', t1 = h1, t2 = h2, plag = round(document_similarity*100,2)) 


@app.route('/suggestion/', methods = ['POST'])
def suggestion():
    if request.method == 'POST':
        parrot = Parrot(model_tag="prithivida/parrot_paraphraser_on_T5", use_gpu=False)
        main_input = request.form['text']
        phrases = [main_input]
        suggestions = []
        res = []
        for phrase in phrases:
            # print("-"*100)
            # print("Input_phrase: ", phrase)
            # print("-"*100)
            para_phrases = parrot.augment(input_phrase=phrase)
            for para_phrase in para_phrases:
                # print(para_phrase)
                suggestions.append(para_phrase)
        
        j = 1
        for sug,i in suggestions:
            res.append(str(j)+'. '+sug)
            j+=1
        return render_template('suggestion.html', data = res ) 
    

if __name__ == "__main__":
    app.run(debug = True)
    